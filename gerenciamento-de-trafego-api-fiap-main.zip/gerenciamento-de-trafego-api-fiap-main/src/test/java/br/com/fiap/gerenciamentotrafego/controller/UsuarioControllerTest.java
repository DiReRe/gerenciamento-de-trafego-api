package br.com.fiap.gerenciamentotrafego.controller;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UsuarioControllerTest {

    @Test
    void cadastrar() {
    }

    @Test
    void listarUsuarios() {
    }
}
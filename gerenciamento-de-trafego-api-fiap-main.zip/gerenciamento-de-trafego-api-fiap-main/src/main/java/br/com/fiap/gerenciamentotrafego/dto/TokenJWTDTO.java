package br.com.fiap.gerenciamentotrafego.dto;

public record TokenJWTDTO(String token) {
}

package br.com.fiap.gerenciamentotrafego.dto;

public record ViagensCadastroDTO(
        Long idViagens,
        Integer distancia,
        Integer velTrafego
) {
}

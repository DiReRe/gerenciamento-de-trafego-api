package br.com.fiap.gerenciamentotrafego;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GerenciamentoTrafegoApplication {

	public static void main(String[] args) {
		SpringApplication.run(GerenciamentoTrafegoApplication.class, args);
	}

}
